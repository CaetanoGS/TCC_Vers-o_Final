********************
``matplotlib.style``
********************

.. automodule:: matplotlib.style
   :members:
   :undoc-members:
   :show-inheritance:
   :imported-members:

.. data:: matplotlib.style.library

   Dictionary of available styles

.. data:: matplotlib.style.available

   List of available styles
