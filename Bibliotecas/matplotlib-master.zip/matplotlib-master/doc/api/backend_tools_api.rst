
:mod:`matplotlib.backend_tools`
===============================

.. automodule:: matplotlib.backend_tools
   :members:
   :undoc-members:
   :show-inheritance:
