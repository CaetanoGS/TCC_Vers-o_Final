
================
 Old API Changes
================

.. toctree::
   :glob:
   :reversed:
   :maxdepth: 1

   prev_api_changes/*
