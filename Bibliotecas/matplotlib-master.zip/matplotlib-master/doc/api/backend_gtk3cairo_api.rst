
:mod:`matplotlib.backends.backend_gtk3cairo`
============================================

**TODO** We'll add this later, importing the gtk3 backends requires an active
X-session, which is not compatible with cron jobs.

.. .. automodule:: matplotlib.backends.backend_gtk3cairo
..    :members:
..    :undoc-members:
..    :show-inheritance:
