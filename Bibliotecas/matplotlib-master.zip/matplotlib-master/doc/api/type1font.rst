************************
``matplotlib.type1font``
************************

.. automodule:: matplotlib.type1font
   :members:
   :undoc-members:
   :show-inheritance:
