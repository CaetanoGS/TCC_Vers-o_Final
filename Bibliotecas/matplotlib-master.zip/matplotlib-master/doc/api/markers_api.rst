**********************
``matplotlib.markers``
**********************

.. currentmodule:: matplotlib.markers

.. automodule:: matplotlib.markers
   :no-members:
   :no-inherited-members:

Classes
-------

.. autosummary::
   :toctree: _as_gen/
   :template: autosummary.rst

   MarkerStyle
