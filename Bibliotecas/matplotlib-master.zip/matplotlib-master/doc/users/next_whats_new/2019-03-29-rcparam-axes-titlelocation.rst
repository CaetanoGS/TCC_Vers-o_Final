rcParam for default axes title location
---------------------------------------

A new rcParam value ``axes.titlelocation`` denotes the default axes title alignment.

Valid values are: left, center, and right.
