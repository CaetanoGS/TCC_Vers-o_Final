Gouraud-shaded mesh alpha channels in the pdf backend
-----------------------------------------------------

The pdf backend now supports an alpha channel in Gouraud-shaded
triangle meshes.
