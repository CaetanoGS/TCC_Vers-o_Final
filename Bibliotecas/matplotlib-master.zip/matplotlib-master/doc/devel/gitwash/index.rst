.. _using-git:

Working with *Matplotlib* source code
================================================

Contents:

.. toctree::
   :maxdepth: 2

   git_intro
   git_install
   following_latest
   patching
   git_development
   git_resources
   dot2_dot3


