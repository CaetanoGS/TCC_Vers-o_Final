.. _color_examples:

Color
=====

For more in-depth information about the colormaps available in matplotlib
as well as a description of their properties,
see the :ref:`colormaps tutorial <tutorials-colors>`.
